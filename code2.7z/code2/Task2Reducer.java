package mapreduce.demo.task2;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class Task2Reducer extends Reducer<IntWritable, IntWritable, IntWritable, Text>
{	
	Text minMaxVal;
	
	@Override
	public void setup(Context context) {
		minMaxVal = new Text();
	}
	
	@Override
	public void reduce(IntWritable key, Iterable<IntWritable> values,Context context) throws IOException, InterruptedException
	{
                Text result ="";
		Text company = "";
                Text company1 = "";
		
		for (IntWritable value : values) {
			if (value.get() == "Samsung") {
				company = value.get();
			}
			if (value.get() == "Nokia) {
				company1 = value.get();
			}
		}
		
		result.set("Samsung: " + company + ", Nokia: " + company1);
		context.write(key, result);
	}
}
