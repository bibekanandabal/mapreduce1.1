package mapreduce.demo.task2;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.*; 

public class Task2Mapper extends Mapper<LongWritable, Text, IntWritable, IntWritable> {
		
	Text company;
	Text product;
	
	@Override
	public void setup(Context context) {
		company= new Text();
		product= new Text();
	}
	
	@Override
	public void map(LongWritable key, Text value, Context context) 
			throws IOException, InterruptedException {
		String[] lineArray = value.toString().split("|");
		
		company.set(Integer.parseInt(lineArray[1]));
		product.set(Integer.parseInt(lineArray[2]));
		
		context.write(company, product);
	}
}
